document.addEventListener("DOMContentLoaded", function() {
    const textElements = document.querySelectorAll('.text h1');
    const mountainImage = document.querySelector('.mount img');
    
    textElements.forEach(function(textElement) {
        const randomX = Math.random() * (window.innerWidth - textElement.offsetWidth);
        const randomY = Math.random() * (window.innerHeight - textElement.offsetHeight);
        
        textElement.style.position = 'absolute';
        textElement.style.left = randomX + 'px';
        textElement.style.top = randomY + 'px';
    });
});
