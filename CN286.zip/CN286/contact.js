function showIcons(card) {
    card.querySelector('.social-icons').style.opacity = '1';
}

function hideIcons(card) {
    card.querySelector('.social-icons').style.opacity = '0';
}